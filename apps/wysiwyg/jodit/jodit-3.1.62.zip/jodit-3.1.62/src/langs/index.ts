/*!
 * Jodit Editor (https://xdsoft.net/jodit/)
 * License https://xdsoft.net/jodit/license.html
 * Copyright 2013-2018 Valeriy Chupurnov https://xdsoft.net
 */

export {default as de} from './de';
export {default as en} from './en';
export {default as fr} from './fr';
export {default as ru} from './ru';
export {default as ar} from './ar';
